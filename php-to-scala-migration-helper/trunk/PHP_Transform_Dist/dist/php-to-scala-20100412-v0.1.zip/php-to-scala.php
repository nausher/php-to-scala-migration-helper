<?
/*
 * PHP-to-Scala source code migration helper.
 *
 * Copyright(C) 2010 Alex T. Ramos / Zigabyte Corporation.
 * COPYING is permitted under the terms of the GNU General Public License, v3.
 *
 * CURRENT STATUS / FUNCTIONALITY:
 *
 * This script should be used as a "helper" for porting PHP code to Scala.
 *
 * It is not a complete source code converter. It just tries to get the syntax right
 * as a way to minimize the number of mind-numbing manual edits. The user is still
 * responsible for several "details", e.g. chasing down all undeclared variables, which
 * will be pointed out by the Scala compiler, and choosing an appropriate type for
 * each.
 *
 * This script is NOT intended as a "compiler" to make the PHP code "run faster".
 * It is for people who've reached the limits of the PHP language itself and want to
 * get rid of it ASAP. Any improvement in speed is just a welcome side-effect.
 *
 * Some specific constructs/features implemented include:
 * - Use the built-in PHP tokenizer for correctness (should handle complex scripts)
 * - Recursive "look-ahead" parser avoids an AST, this helps preserve code structure.
 * - Breaking up of for(;;) loops into scala while() loops is working.
 * - Use correct syntax for function declaration (including no '=' for non-returning)
 * - Removal of dollar signs from all variables
 * - Change of array index [] to ().
 * - Change of object operator -> to '.'
 * - Inline HTML for now just invokes an "output" function with triple-quoted string.
 * - Correct handling of command-syntax (e.g. print) by adding parenthesis.
 * - File scope becomes an object scope; this should help a later "aliasing" scheme.
 *
 * TODO ITEMS
 * - The attached test_1.php output (test_1.scala) currently has 58 errors.
 * - The medium-term goal is to get this simple test_1.php to convert with no errors.
 */

$file = $argv[1];
$code = file_get_contents($file);

$conv = new PhpToScala();
echo $conv->convert($code, $file);

class PhpToScala {

	function match($token1, $ttype) {
		if(is_array($token1)) {
			return $token1[TTYPE] == $ttype;
		}
		else {
			return $token1 === $ttype;
		}
	}

	function contains(array $T, $ttype) {
		foreach($T as $t) {
			if($this->match($t, $ttype)) {
				return true;
			}
		}
		return false;
	}

	function skip(&$T, $ttype) {
		while($this->match($T[0], $ttype)) {
			array_shift($T);
		}
	}

	function display($token) {
		return is_array($token) ? token_name($token[TTYPE]) : $token;
	}

	function eat(&$T, $ttype) {
		$this->skip($T, T_WHITESPACE);
		$t = array_shift($T);
		if(!$this->match($t, $ttype)) {
			throw new Exception('Expected: ' . ($this->display($ttype)) . " got: " . var_export($t));
		}
	}

	function parse_expr(&$T, $terminator) {
		$out = '';
		while($T[0] !== ')' && $T[0] !== ';') {
			if($T[0] === '(') {
				array_shift($T);
				$out .= '(' . $this->parse_expr($T, ')') . ')';
			}
			else {
				$out .= $this->parse($T);
			}
		}
		array_shift($T);
		return $out;
	}

	function parse_block(&$T) {
		while($T[0] !== '}') {
			if($T[0] === '{') {
				array_shift($T);
				return "{ " . parse_block($T) . " }";
			}
			else {
				parse($T);
			}
		}
		array_shift($T);
	}

	function get_block(&$T) {
		$out = array();
		while(count($T) && $T[0] != '}') {
			$t = array_shift($T);
			if($t == '{') {
				$out[] = '{';
				array_splice($out, count($out), 0, $this->get_block($T));
				$out[] = '}';
			}
			else {
				$out[] = $t;
			}
		}
		array_shift($T);
		return $out;
	}

	function parse_stmt(&$T) {
		$this->skip($T, T_WHITESPACE);
		if($T[0] === '{') {
			return $this->parse_block($T);
		}
		else {
			return "{ " . $this->parse_expr($T, ';') . " }";
		}
	}

	function parse_for(&$T) {
		$this->eat($T, '(');
		$init_expr = $this->parse_expr($T, ';');
		$cond_expr = $this->parse_expr($T, ';');
		$term_expr = $this->parse_expr($T, ')');
		$body_stmt = $this->parse_stmt($T);
		return "$init_expr;\nwhile($cond_expr) {\n $body_stmt; $term_expr }\n";
	}

	function parse_function(&$T) {
		$out = "def";
		while($T[0] != '{') {
			$prev = $T[0];
			$out .= $this->parse($T);
			if($prev[TTYPE] == T_VARIABLE) {
				$out .= ": php.value";
			}
		}
		$this->eat($T, '{');
		$body = $this->get_block($T);

		if($this->contains($body, T_RETURN)) {
			$out .= ": php.value = ";
		}
		return $out . '{' . $this->parse_all($body) . '}';
	}

	function parse_vars(&$T) {
		$out = '';
		while($T[0] != ';') {
			if($T[0][TTYPE] == T_VARIABLE) {
				$out .= "var " . $this->parse($T) . " = undef;\n";
			}
			else {
				array_shift($T);
			}
		}
		array_shift($T);
		return $out;
	}

	function parse_command(&$T) {
		$t = array_shift($T);
		return $t[VALUE] . ' (' . $this->parse_expr($T, ';') . ');';
	}

	function parse(&$T) {

		$t = array_shift($T);

		if(!is_array($t)) {
			switch($t) {
				case '[': return '(';
				case ']': return ')';
				default:
					return $t;
			}
		}

		switch($t[TTYPE]) {

			case T_INLINE_HTML:
				return 'output """' . $t[VALUE] . '"""' . "\n";

			case T_CLOSE_TAG: #     ? > or % >  escaping from HTML
			case T_OPEN_TAG: #  < ?php, < ? or < %  escaping from HTML
				return "";

			case T_FUNCTION: #  function or cfunction   functions
				return $this->parse_function($T);

			case T_OBJECT_OPERATOR: #   ->  classes and objects
				return ".";

			case T_VARIABLE: #  $foo    variables
				return substr($t[VALUE],1);

			case T_VAR: #   var     classes and objects
				return $this->parse_vars($T);

			case T_FOR: #   for     for
				return $this->parse_for($T);

			case T_PRINT: #     print()     print()
				return $this->parse_command($T);

			case T_COMMENT: #   // or #, and /* */ in PHP 5     comments
			case T_ABSTRACT: #      abstract    Class Abstraction (available since PHP 5.0.0)
			case T_AND_EQUAL: #     &=  assignment operators
			case T_ARRAY: #     array()     array(), array syntax
			case T_ARRAY_CAST: #    (array)     type-casting
			case T_AS: #    as  foreach
			case T_BAD_CHARACTER: #         anything below ASCII 32 except \t (0x09), \n (0x0a) and \r (0x0d)
			case T_BOOLEAN_AND: #   &&  logical operators
			case T_BOOLEAN_OR: #    ||  logical operators
			case T_BOOL_CAST: #     (bool) or (boolean)     type-casting
			case T_BREAK: #     break   break
			case T_CASE: #  case    switch
			case T_CATCH: #     catch   Exceptions (available since PHP 5.0.0)
			case T_CHARACTER: #         not used anymore
			case T_CLASS: #     class   classes and objects
			case T_CLASS_C: #   __CLASS__   magic constants (available since PHP 4.3.0)
			case T_CLONE: #     clone   classes and objects (available since PHP 5.0.0)
			case T_CONCAT_EQUAL: #  .=  assignment operators
			case T_CONST: #     const   class constants
			case T_CONSTANT_ENCAPSED_STRING: #  "foo" or 'bar'  string syntax
			case T_CONTINUE: #  continue    continue
			case T_CURLY_OPEN: #    {$  complex variable parsed syntax
			case T_DEC: #   --  incrementing/decrementing operators
			case T_DECLARE: #   declare     declare
			case T_DEFAULT: #   default     switch
			case T_DIR: #   __DIR__     magic constants (available since PHP 5.3.0)
			case T_DIV_EQUAL: #     /=  assignment operators
			case T_DNUMBER: #   0.12, etc   floating point numbers
			case T_DOC_COMMENT: #   /** */  PHPDoc style comments (available since PHP 5.0.0)
			case T_DO: #    do  do..while
			case T_DOLLAR_OPEN_CURLY_BRACES: #  ${  complex variable parsed syntax
			case T_DOUBLE_ARROW: #  =>  array syntax
			case T_DOUBLE_CAST: #   (real), (double) or (float)     type-casting
			case T_DOUBLE_COLON: #  ::  see T_PAAMAYIM_NEKUDOTAYIM below
			case T_ECHO: #  echo    echo()
			case T_ELSE: #  else    else
			case T_ELSEIF: #    elseif  elseif
			case T_EMPTY: #     empty   empty()
			case T_ENCAPSED_AND_WHITESPACE: #   " $a"   constant part of string with variables
			case T_ENDDECLARE: #    enddeclare  declare, alternative syntax
			case T_ENDFOR: #    endfor  for, alternative syntax
			case T_ENDFOREACH: #    endforeach  foreach, alternative syntax
			case T_ENDIF: #     endif   if, alternative syntax
			case T_ENDSWITCH: #     endswitch   switch, alternative syntax
			case T_ENDWHILE: #  endwhile    while, alternative syntax
			case T_END_HEREDOC: #       heredoc syntax
			case T_EVAL: #  eval()  eval()
			case T_EXIT: #  exit or die     exit(), die()
			case T_EXTENDS: #   extends     extends, classes and objects
			case T_FILE: #  __FILE__    magic constants
			case T_FINAL: #     final   Final Keyword (available since PHP 5.0.0)
			case T_FOREACH: #   foreach     foreach
			case T_FUNC_C: #    __FUNCTION__    magic constants (available since PHP 4.3.0)
			case T_GLOBAL: #    global  variable scope
			case T_GOTO: #  goto    (available since PHP 5.3.0)
			case T_HALT_COMPILER: #     __halt_compiler()   __halt_compiler (available since PHP 5.1.0)
			case T_IF: #    if  if
			case T_IMPLEMENTS: #    implements  Object Interfaces (available since PHP 5.0.0)
			case T_INC: #   ++  incrementing/decrementing operators
			case T_INCLUDE: #   include()   include()
			case T_INCLUDE_ONCE: #  include_once()  include_once()
			case T_INLINE_HTML: #       text outside PHP
			case T_INSTANCEOF: #    instanceof  type operators (available since PHP 5.0.0)
			case T_INT_CAST: #  (int) or (integer)  type-casting
			case T_INTERFACE: #     interface   Object Interfaces (available since PHP 5.0.0)
			case T_ISSET: #     isset()     isset()
			case T_IS_EQUAL: #  ==  comparison operators
			case T_IS_GREATER_OR_EQUAL: #   >=  comparison operators
			case T_IS_IDENTICAL: #  ===     comparison operators
			case T_IS_NOT_EQUAL: #  != or <>    comparison operators
			case T_IS_NOT_IDENTICAL: #  !==     comparison operators
			case T_IS_SMALLER_OR_EQUAL: #   <=  comparison operators
			case T_LINE: #  __LINE__    magic constants
			case T_LIST: #  list()  list()
			case T_LNUMBER: #   123, 012, 0x1ac, etc    integers
			case T_LOGICAL_AND: #   and     logical operators
			case T_LOGICAL_OR: #    or  logical operators
			case T_LOGICAL_XOR: #   xor     logical operators
			case T_METHOD_C: #  __METHOD__  magic constants (available since PHP 5.0.0)
			case T_MINUS_EQUAL: #   -=  assignment operators
			case T_ML_COMMENT: #    /* and */   comments (PHP 4 only)
			case T_MOD_EQUAL: #     %=  assignment operators
			case T_MUL_EQUAL: #     *=  assignment operators
			case T_NS_C: #  __NAMESPACE__   namespaces. Also defined as T_NAMESPACE (available since PHP 5.3.0)
			case T_NEW: #   new     classes and objects
			case T_NUM_STRING: #    "$a[0]"     numeric array index inside string
			case T_OBJECT_CAST: #   (object)    type-casting
			case T_OLD_FUNCTION: #  old_function    (PHP 4 Only)
			case T_OPEN_TAG_WITH_ECHO: #    <?= or <%=  escaping from HTML
			case T_OR_EQUAL: #  |=  assignment operators
			case T_PAAMAYIM_NEKUDOTAYIM: #  ::  ::. Also defined as T_DOUBLE_COLON.
			case T_PLUS_EQUAL: #    +=  assignment operators
			case T_PRIVATE: #   private     classes and objects (available since PHP 5.0.0)
			case T_PUBLIC: #    public  classes and objects (available since PHP 5.0.0)
			case T_PROTECTED: #     protected   classes and objects (available since PHP 5.0.0)
			case T_REQUIRE: #   require()   require()
			case T_REQUIRE_ONCE: #  require_once()  require_once()
			case T_RETURN: #    return  returning values
			case T_SL: #    <<  bitwise operators
			case T_SL_EQUAL: #  <<=     assignment operators
			case T_SR: #    >>  bitwise operators
			case T_SR_EQUAL: #  >>=     assignment operators
			case T_START_HEREDOC: #     <<<     heredoc syntax
			case T_STATIC: #    static  variable scope
			case T_STRING: #    "$a[a]"     string array index inside string
			case T_STRING_CAST: #   (string)    type-casting
			case T_STRING_VARNAME: #    "${a    complex variable parsed syntax
			case T_SWITCH: #    switch  switch
			case T_THROW: #     throw   Exceptions (available since PHP 5.0.0)
			case T_TRY: #   try     Exceptions (available since PHP 5.0.0)
			case T_UNSET: #     unset()     unset()
			case T_UNSET_CAST: #    (unset)     type-casting (available since PHP 5.0.0)
			case T_USE: #   use     namespaces (available since PHP 5.3.0)
			case T_WHILE: #     while   while, do..while
			case T_WHITESPACE: #    \t \r\n
			case T_XOR_EQUAL: #     ^=  assignment operators
				return $t[VALUE];

			default:
				throw new Exception("unknown token: " . token_name($t[TTYPE]));
		}
	}

	public function parse_all($T) {
		$out = '';

		while(count($T)) {
			$out .= $this->parse($T);
		}
		return $out;
	}

	public function convert($code, $file) {
		echo "import php._;\n\nobject " . preg_replace('/\W/', '_', $file) . " extends php.context {\n";
		echo $this->parse_all(token_get_all($code));
		echo "}";
	}

	function __construct() {
		define(TTYPE, 0);
		define(VALUE, 1);
	}

	function dump($tokens) { // debugging function
		foreach($tokens as $c) {
			if(is_array($c)) {
				$disp = preg_replace("/[\r\n]+/", "\\n", $c[1]);
				print(token_name($c[0]) . ": '" . $disp . "'\n");
			}
			else {
				print("$c\n");
			}
		}
	}
}
?>

