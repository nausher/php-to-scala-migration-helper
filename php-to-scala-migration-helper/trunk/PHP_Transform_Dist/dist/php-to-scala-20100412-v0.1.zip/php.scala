package php;

class value(a: Any) {
}

class context {

  val undef : value = null
  
}
