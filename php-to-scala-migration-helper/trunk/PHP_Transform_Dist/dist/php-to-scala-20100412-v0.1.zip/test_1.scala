import php._;

object test_1_php extends php.context {
 /* The Great Computer Language Shootout
   http://shootout.alioth.debian.org/

   contributed by Isaac Gouy

   php -q pidigits.php 27
*/


class Transformation {
   var q = undef;
var r = undef;
var s = undef;
var t = undef;
var k = undef;


   def Transformation(q: php.value, r: php.value, s: php.value, t: php.value){
      this.q = q;
      this.r = r;
      this.s = s;
      this.t = t;
   }

   def Unity(): php.value = {
      return new Transformation("1", "0", "0", "1");
   }

   def Zero(): php.value = {
      return new Transformation("0", "0", "0", "0");
   }


   def Compose(a: php.value): php.value = {
      qq = bcmul(this.q, a.q);
      qrrt = bcadd(bcmul(this.q, a.r), bcmul(this.r, a.t));
      sqts = bcadd(bcmul(this.s, a.q), bcmul(this.t, a.s));
      srtt = bcadd(bcmul(this.s, a.r), bcmul(this.t, a.t));
      return new Transformation(qq, qrrt, sqts, srtt);
   }

   def Extract(j: php.value): php.value = {
      bigj = strval(j);
      qjr = bcadd(bcmul(this.q, bigj), this.r);
      sjt = bcadd(bcmul(this.s, bigj), this.t);
      d = bcdiv(qjr, sjt);
      return floor(d);
   }

   def Next(): php.value = {
      this.k = this.k + 1;
      this.q = strval(this.k);
      this.r = strval(4*this.k + 2);
      this.s = "0";
      this.t = strval(2*this.k + 1);
      return this;
   }
}



class PiDigitStream {
   var z = undef;
var x = undef;
var inverse = undef;


   def PiDigitStream(){
      this.z = Transformation::Unity();
      this.x = Transformation::Zero();
      this.inverse = Transformation::Zero();
   }

   def Produce(j: php.value): php.value = {
      i = this.inverse;
      i.q = "10";
      i.r = strval(-10*j);
      i.s = "0";
      i.t = "1";
      return i.Compose(this.z);
   }

   def Consume(a: php.value): php.value = {
      return this.z .Compose(a);
   }

   def Digit(): php.value = {
      return this.z .Extract(3);
   }

   def IsSafe(j: php.value): php.value = {
      return j == (this.z .Extract(4));
   }

   def Next(): php.value = {
      y = this.Digit();
      if (this.IsSafe(y)){
         this.z = this.Produce(y);
         return y;
      } else {
         this.z = this.Consume(this.x .Next());
         return this.Next();
      }
   }
}


n = argv(1);
i = 0;
length = 10;
pidigit = new PiDigitStream;

while (n > 0){
   if (n < length){
      j=0;
while( j<n) {
 { printf("%d",pidigit.Next()) };  j++ }

      j=n;
while( j<length) {
 {   (" ");
      i += n };  j++ }

   } else {
      j=0;
while( j<length) {
 { printf("%d",pidigit.Next()) };  j++ }

      i += length;
   }
     ("\t:i\n");
   n -= length;
}
}
