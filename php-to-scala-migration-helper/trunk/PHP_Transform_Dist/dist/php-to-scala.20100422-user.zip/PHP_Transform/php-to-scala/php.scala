/*
 * Scala/Quercus integration layer.
 * See http://code.google.com/p/php-to-scala-migration-helper/ for details.
 *
 * Copyright(C) 2010 Alex T. Ramos / Zigabyte Corporation.
 * COPYING is permitted under the terms of the GNU General Public License, v3.
 *
 * $Id: php.scala,v 1.11 2010-04-22 18:39:00 alex Exp $
 */

package php

import phplib._;
import com.caucho.quercus.env._;

abstract class $ {
  def value: Value

  // exception for operations that are only supported on specific types (Int, Obj ,etc)
  def wrong_type = throw new Exception("incorrect dynamic type for op: " + this.getClass)

  def update(sym: Symbol, new_val: $): $ = wrong_type

  def ~&(sym: Symbol): method_ref = wrong_type

  def ~>(sym: Symbol): $ = wrong_type

  def ++() : $ = wrong_type

  def -=(o: $): $ = wrong_type

  def +=(o: $): $ = wrong_type

  def +(o: $) = value.add(o.value)

  def *(o: $) = value.mul(o.value)

  def +(i: Int) = value.toInt + i

  def *(i: Int) = value.toInt * i

  def >(o: $) = value.gt(o.value)

  def <(o: $) = value.lt(o.value)

  def ==(o: $) : Boolean = value.eq(o.value);

  def toBoolean = this.value.toBoolean

  def toInt = this.value.toInt;

  override def toString = value.toString
}

class $null extends $ {
  override def value = new ConstStringValue("");  
}

class $val(v: Value) extends $ {
  override def value = v;
}

class $int(var i: Int) extends $ {
  override def value = new LongValue(i)
  override def -=(x: $): $ = { this.i = this.i - x.toInt; this }
  override def +=(x: $): $ = { this.i = this.i + x.toInt; this }
  override def ++(): $ = { this.i = this.i + 1; this } /* due to Scala quirk, cannot write this.i++ here */  
}

class $str(var s: String) extends $ {
  override def value = new ConstStringValue(s)
  override def -=(x: $): $ = { this.s = (this.toInt - x.toInt).toString; this }
  override def +=(x: $): $ = { this.s = (this.toInt + x.toInt).toString; this }
}

class method_ref(o: AnyRef, m: java.lang.reflect.Method) {
  private def objectize(a: AnyRef): $ = {
    a match {
      case php: $ => return php;
      case i: Integer => return new $int(i.intValue);
      case other: AnyRef => throw new Exception("unhandled: " + other.getClass);
    }
  }

  def ~>(args: Any*): $ = {
    var a: Array[AnyRef] = args.toArray.map {a: Any => objectize(a.asInstanceOf[AnyRef])};
    return callRef(a: _*);
  }

  private def callRef(args: AnyRef*): $ = {
    var oa: Array[Object] = args.toArray.map {_.asInstanceOf[Object]};
    //println("calling: " + m.toString + " with: " + oa.length + " args");

    m.invoke(o, oa: _*) match {
      case x: $ => x;
      case u => throw new Exception("unknown result" + u);
    }
  }
}


class $obj extends $ {
  override def value = throw new Exception("objects do not have a value")

  override def ~&(sym: Symbol): method_ref = {
    val s = sym.toString.substring(1)

    var m = for{i <- this.getClass.getDeclaredMethods() if i.getName == s
    } yield i;
    if (m.length > 0) return new method_ref(this, m(0));
    throw new Exception("object class " + this.getClass + " no method " + s)
  }

  override def ~>(sym: Symbol): $ = {
    val s = sym.toString.substring(1)
    val f = this.getClass.getDeclaredField(s);
    f.setAccessible(true);
    val v = f.get(this);
    //println("Value of " + s + " = " + v);
    v match {
      case o: $ => return o;
      case u => throw new Exception("unknown result" + u);
    }
    return new $str(v.toString);
  }

  override def update(sym: Symbol, new_val: $): $ = {
    val s = sym.toString.substring(1)
    val f = this.getClass.getDeclaredField(s);
    f.setAccessible(true);
    f.set(this, new_val);
    //println("Value of " + s + " set to " + new_val);
    return new_val;
  }

  override def toString = "object[" + this.getClass + "]"
}

class $bool(b: Boolean) extends $ {
  override def value = BooleanValue.create(b);
}

abstract class script extends phplib(System.out) {
  def include;

  val undef: $ = new $null;

  var argv = Array(this.toString);

  def main(args: Array[String]) {
    argv = argv ++ args;
    this.include;
  }

  implicit def stringToPhp(s: String): $ = new $str(s)

  implicit def stringToQuercus(s: String): StringValue = new ConstStringValue(s)

  implicit def intToQuercus(i: Int): LongValue = new LongValue(i)

  implicit def quercusToInt(v: Value): Int = v.value.toInt

  implicit def intToPhp(i: Int): $int = new $int(i)

  implicit def phpToInt(a: $): Int = a.toInt

  implicit def phpToPhpInt(a: $): $int = a.toInt

  implicit def booleanToPhp(b: Boolean): $ = new $bool(b)

  implicit def phpToBoolean(a: $): Boolean = a.toBoolean

  implicit def quercusToPhp(v: Value): $ = new $val(v)

  implicit def phpToQuercus(a: $): Value = a.value

  def printf(f: String, args: $*) {
    var values = args.map {arg => arg.value};
    Predef.print(sprintf(f, values.toArray));
  }

  def echo(s: String) = Predef.print(s)

  def echo(i: Int) = Predef.print(i)

}
