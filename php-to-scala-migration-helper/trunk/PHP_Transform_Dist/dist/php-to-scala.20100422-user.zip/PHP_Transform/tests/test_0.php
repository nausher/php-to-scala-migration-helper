<?

  echo("Hello, World\n");

  for($i=1; $i <= 3; ++$i) {
   echo($i);
   echo("\n");
  }

?>
