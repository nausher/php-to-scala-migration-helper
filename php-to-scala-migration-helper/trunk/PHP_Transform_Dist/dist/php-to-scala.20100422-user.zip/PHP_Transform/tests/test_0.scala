import php._;
import scala.Predef.{any2stringadd => _, any2ArrowAssoc => _}

object test_0_php extends php.script {
  override def include {
var i: $int = 0;

  echo("Hello, World\n");

  
i=1;
while( i <= 3) {
 { 
   echo(i);
   echo("\n");
   }

;
 (i = i + 1)
}
  }
}
