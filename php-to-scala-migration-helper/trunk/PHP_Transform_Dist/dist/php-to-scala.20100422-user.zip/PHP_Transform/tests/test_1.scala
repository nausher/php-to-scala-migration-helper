import php._;
import scala.Predef.{any2stringadd => _, any2ArrowAssoc => _}

object test_1_php extends php.script {
  override def include {
var n: $ = undef;
var i: $int = 0;
var length: $int = 0;
var pidigit: $ = undef;
var j: $int = 0; /* The Great Computer Language Shootout
   http://shootout.alioth.debian.org/

   contributed by Isaac Gouy

   php -q pidigits.php 27
*/


class Transformation  extends $obj {
   var q = undef;
var r = undef;
var s = undef;
var t = undef;
var k = undef;


   def __construct (q: $, r: $, s: $, t: $):$ = {
      this.q = q;
      this.r = r;
      this.s = s;
      this.t = t;
   
this;
}

   def Unity(): $ = {

      return new Transformation __construct("1", "0", "0", "1");
   }

   def Zero(): $ = {

      return new Transformation __construct("0", "0", "0", "0");
   }


   def Compose(a: $): $ = {
var qq: $ = undef;
var qrrt: $ = undef;
var sqts: $ = undef;
var srtt: $ = undef;

      qq = bcmul(this.q, a~>'q);
      qrrt = bcadd(bcmul(this.q, a~>'r), bcmul(this.r, a~>'t));
      sqts = bcadd(bcmul(this.s, a~>'q), bcmul(this.t, a~>'s));
      srtt = bcadd(bcmul(this.s, a~>'r), bcmul(this.t, a~>'t));
      return new Transformation __construct(qq, qrrt, sqts, srtt);
   }

   def Extract(j: $): $ = {
var bigj: $ = undef;
var qjr: $ = undef;
var sjt: $ = undef;
var d: $ = undef;

      bigj = strval(j);
      qjr = bcadd(bcmul(this.q, bigj), this.r);
      sjt = bcadd(bcmul(this.s, bigj), this.t);
      d = bcdiv(qjr, sjt);
      return floor(d);
   }

   def Next(): $ = {

      this.k = this.k + 1;
      this.q = strval(this.k);
      this.r = strval(4*this.k + 2);
      this.s = "0";
      this.t = strval(2*this.k + 1);
      return this;
   }

}
object Transformation extends Transformation;



class PiDigitStream  extends $obj {
   var z = undef;
var x = undef;
var inverse = undef;


   def __construct ():$ = {
      this.z = Transformation.Unity();
      this.x = Transformation.Zero();
      this.inverse = Transformation.Zero();
   
this;
}

   def Produce(j: $): $ = {
var i: $ = undef;

      i = this.inverse;
      i('q) = "10";
      i('r) = strval(-10*j);
      i('s) = "0";
      i('t) = "1";
      return i~&'Compose~>(this.z);
   }

   def Consume(a: $): $ = {

      return this.z ~&'Compose~>(a);
   }

   def Digit(): $ = {

      return this.z ~&'Extract~>(3);
   }

   def IsSafe(j: $): $ = {

      return j == (this.z ~&'Extract~>(4));
   }

   def Next(): $ = {
var y: $ = undef;

      y = this.Digit();
      if (this.IsSafe(y)){
         this.z = this.Produce(y);
         return y;
      } else {
         this.z = this.Consume(this.x ~&'Next~>());
         return this.Next();
      }
   }

}
object PiDigitStream extends PiDigitStream;


n = argv(1);
i = 0;
length = 10;
pidigit = new PiDigitStream __construct;

while (n > 0){
   if (n < length){
      
j=0;
while( j<n) {
 { printf("%d",pidigit~&'Next~>()) };
 j++
}

      
j=n;
while( j<length) {
 { echo(" ")
      i += n };
 j++
}

   } else {
      
j=0;
while( j<length) {
 { printf("%d",pidigit~&'Next~>()) };
 j++
}

      i += length;
   }
   echo("\t:"+i+"\n")
   n -= length;
}
  }
}
